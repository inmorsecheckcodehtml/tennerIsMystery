tennerIsMystery - adventure.zip

This archive is a placeholder for the ARG. Replace or add files here
with puzzles, clues, images, or small text files your players must find.

Files included:
 - clue1.txt  (a small puzzle)
 - secret_note.txt (decoded binary message)
